﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarBehaviourScript : MonoBehaviour {

    private Rigidbody body;

    public GameObject FL;
    public GameObject FR;
    public GameObject BL;
    public GameObject BR;

    public WheelCollider WheelFL;
    public WheelCollider WheelFR;
    public WheelCollider WheelBL;
    public WheelCollider WheelBR;

    public float speed;
    public float maxSteerAngle = 60.0f;
    public float maxSpeed = 250.0f;
    public float maxTorque = 250.0f;
    public float maxBrakeTorque = 2500.0f;

    private float z;
    private float x;
    private float brake;

    

    // Use this for initialization
    void Start ()
    {
        body = GetComponent<Rigidbody>();
	}

    void FixedUpdate () {

        x = Input.GetAxis("Horizontal");
        z = Input.GetAxis("Vertical");
        brake = Input.GetAxis("Jump");

        WheelFL.steerAngle = maxSteerAngle * x;
        WheelFR.steerAngle = maxSteerAngle * x;

        speed = 2 * 22 / 7 * WheelBL.radius * WheelBL.rpm * 60 / 1000;

        if (speed < maxSpeed)
        {
            WheelBL.motorTorque = maxTorque * z;
            WheelBR.motorTorque = maxTorque * z;
        }

        WheelFL.brakeTorque = maxBrakeTorque * brake;
        WheelFR.brakeTorque = maxBrakeTorque * brake;
        WheelBL.brakeTorque = maxBrakeTorque * brake;
        WheelBR.brakeTorque = maxBrakeTorque * brake;
    }

  void Update()
     {
        Quaternion WCRotFL;
        Vector3 WCPosFL;
        WheelFL.GetWorldPose(out WCPosFL, out WCRotFL);
        FL.transform.position = WCPosFL;
        FL.transform.rotation = WCRotFL;

        Quaternion WCRotFR;
        Vector3 WCPosFR;
        WheelFL.GetWorldPose(out WCPosFR, out WCRotFR);
        FL.transform.position = WCPosFR;
        FL.transform.rotation = WCRotFR;

        Quaternion WCRotBL;
        Vector3 WCPosBL;
        WheelFL.GetWorldPose(out WCPosBL, out WCRotBL);
        FL.transform.position = WCPosBL;
        FL.transform.rotation = WCRotBL;

        Quaternion WCRotBR;
        Vector3 WCPosBR;
        WheelFL.GetWorldPose(out WCPosBR, out WCRotBR);
        FL.transform.position = WCPosBR;
        FL.transform.rotation = WCRotBR;
    }
}
